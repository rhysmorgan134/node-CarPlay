# React Plain Text Lexical example

Here we have simplest Lexical setup in plaintext configuration (`@lexical/plain-text`) with history (`@lexical/history`) and accessibility (`@lexical/dragon`) features enabled.

**Run it locally:** `npm i && npm run dev`

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/facebook/lexical/tree/main/examples/react-plain-text?file=src/main.tsx)
