# `@lexical/devtools-core`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_devtools_core)

This package contains tools necessary to debug and develop Lexical.
