# `@lexical/clipboard`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_clipboard)

This package contains the functionality for the clipboard feature of Lexical.
