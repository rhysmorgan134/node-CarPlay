# `@lexical/overflow`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_overflow)

This package contains selection overflow helpers and nodes for Lexical.
