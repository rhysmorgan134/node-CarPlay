# `@lexical/link`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_link)

This package contains the functionality for Lexical links.

More documentation coming soon.
