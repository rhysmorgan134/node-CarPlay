# `@lexical/code`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_code)

This package contains the functionality for the code blocks and code highlighting for Lexical.
