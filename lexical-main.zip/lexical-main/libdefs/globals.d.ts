declare module '*.jpg';
declare module '*.jpeg';
declare module '*.gif';
declare module '*.png';
declare module '*.svg';
declare module 'prismjs/components/prism-*';

declare var __DEV__: boolean;
